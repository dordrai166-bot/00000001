const express = require('express');
const argon2 = require('argon2');
const crypto = require('crypto');
const cookie = require('cookie');
const { Pool } = require('pg');
const rateLimit = require('express-rate-limit');

const app = express();
app.use(express.json({ limit: '20kb' })); // these payloads are tiny; cap defensively
app.set('trust proxy', 1); // we're behind nginx — must match actual hop count in front of it

// Minimal security headers. Not adding helmet as a dependency for three headers
// on a JSON-only API — keeps the dependency surface (and attack surface) smaller.
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  next();
});

const pool = new Pool({
  host: process.env.PGHOST || 'auth-postgres',
  port: process.env.PGPORT || 5432,
  user: process.env.PGUSER,
  password: process.env.PGPASSWORD,
  database: process.env.PGDATABASE,
});

const COOKIE_NAME = 'sid';
const COOKIE_DOMAIN = process.env.COOKIE_DOMAIN || '.digi-line.eu';
const SESSION_TTL_HOURS = parseInt(process.env.SESSION_TTL_HOURS || '12', 10);
const ADMIN_KEY = process.env.ADMIN_KEY;

// ---------- helpers ----------

function hashToken(token) {
  return crypto.createHash('sha256').update(token).digest('hex');
}

function newToken() {
  return crypto.randomBytes(32).toString('hex');
}

function setSessionCookie(res, token, expiresAt) {
  res.setHeader('Set-Cookie', cookie.serialize(COOKIE_NAME, token, {
    httpOnly: true,
    secure: true,
    sameSite: 'lax',
    domain: COOKIE_DOMAIN,
    path: '/',
    expires: expiresAt,
  }));
}

function clearSessionCookie(res) {
  res.setHeader('Set-Cookie', cookie.serialize(COOKIE_NAME, '', {
    httpOnly: true,
    secure: true,
    sameSite: 'lax',
    domain: COOKIE_DOMAIN,
    path: '/',
    expires: new Date(0),
  }));
}

// Simple, deliberately permissive email shape check — we're not trying to fully
// validate RFC 5322, just reject garbage and header-injection attempts (\r\n etc).
const EMAIL_RE = /^[^\s@\r\n]+@[^\s@\r\n]+\.[^\s@\r\n]+$/;
function isValidEmail(email) {
  return typeof email === 'string' && email.length <= 254 && EMAIL_RE.test(email);
}

function timingSafeEqualStr(a, b) {
  const bufA = Buffer.from(String(a));
  const bufB = Buffer.from(String(b));
  // Compare against a fixed-length buffer first so mismatched lengths don't
  // short-circuit (and therefore don't leak length via timing either).
  const padded = Buffer.alloc(bufA.length);
  bufB.copy(padded);
  return bufA.length === bufB.length && crypto.timingSafeEqual(bufA, padded);
}

// Most routes below had no try/catch: any DB error (a Postgres restart, a
// dropped connection, a network blip) threw inside an async handler with
// nothing to catch it, which crashes the entire Node process — confirmed live
// against this exact code with the DB unreachable. Since /verify runs on every
// protected page load across every property behind digi-line.eu, a single
// transient DB error would have taken all of them down at once, not just the
// one request. This wrapper turns that into a normal 500 instead.
function asyncHandler(fn) {
  return (req, res, next) => {
    Promise.resolve(fn(req, res, next)).catch((err) => {
      console.error(err);
      if (!res.headersSent) res.status(500).json({ error: 'server_error' });
    });
  };
}

function requireAdmin(req, res, next) {
  const provided = req.headers['x-admin-key'];
  if (!ADMIN_KEY || typeof provided !== 'string' || !timingSafeEqualStr(provided, ADMIN_KEY)) {
    return res.status(403).json({ error: 'forbidden' });
  }
  next();
}

// ---------- rate limiting ----------
// 5 attempts per IP+email per 15 minutes, per P-10 (brute force / lockout protection)

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 5,
  keyGenerator: (req) => `${req.ip}:${(req.body && req.body.email) || ''}`,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'too_many_attempts' },
});

// ---------- register ----------
// Turn this off (return 404) once you're doing account creation another way,
// e.g. from a checkout flow / n8n workflow calling /admin/create-user instead.
// Rate limited per IP: without this, /register was both an unlimited account-
// enumeration oracle (409 vs 200 on email_taken) and a free CPU-exhaustion lever
// (every hit forces a full argon2 hash).

const registerLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 10,
  keyGenerator: (req) => req.ip,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'too_many_attempts' },
});

app.post('/register', registerLimiter, async (req, res) => {
  const { email, password, name, language, theme } = req.body || {};
  if (!isValidEmail(email) || !password || password.length < 10 || password.length > 128) {
    return res.status(400).json({ error: 'invalid_input' });
  }
  const lang = language === 'de' ? 'de' : 'en';
  const th = theme === 'dark' ? 'dark' : 'light';
  const displayName = typeof name === 'string' ? name.trim().slice(0, 100) || null : null;
  try {
    const hash = await argon2.hash(password, { type: argon2.argon2id });
    const result = await pool.query(
      'INSERT INTO users (email, password_hash, display_name, preferred_language, preferred_theme) VALUES ($1, $2, $3, $4, $5) RETURNING id',
      [email.toLowerCase().trim(), hash, displayName, lang, th]
    );
    res.json({ ok: true, user_id: result.rows[0].id });
  } catch (err) {
    if (err.code === '23505') return res.status(409).json({ error: 'email_taken' });
    console.error(err);
    res.status(500).json({ error: 'server_error' });
  }
});

// ---------- login ----------

app.post('/login', loginLimiter, asyncHandler(async (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password || password.length > 128) return res.status(400).json({ error: 'invalid_input' });

  const normEmail = email.toLowerCase().trim();
  const result = await pool.query(
    'SELECT id, password_hash, is_active FROM users WHERE email = $1',
    [normEmail]
  );

  const logAttempt = (success) =>
    pool.query(
      'INSERT INTO login_attempts (email, ip_address, success) VALUES ($1, $2, $3)',
      [normEmail, req.ip, success]
    ).catch((e) => console.error('login_attempts insert failed', e));

  if (result.rows.length === 0) {
    // Run a dummy hash so response timing doesn't reveal whether the email exists
    await argon2.hash('decoy-password-not-real');
    await logAttempt(false);
    return res.status(401).json({ error: 'invalid_credentials' });
  }

  const user = result.rows[0];
  if (!user.is_active) {
    await logAttempt(false);
    return res.status(403).json({ error: 'account_disabled' });
  }

  if (!user.password_hash) {
    // account exists but was created via Google/GitHub/Discord — no password set
    await logAttempt(false);
    return res.status(401).json({ error: 'no_password_set' });
  }

  const valid = await argon2.verify(user.password_hash, password);
  if (!valid) {
    await logAttempt(false);
    return res.status(401).json({ error: 'invalid_credentials' });
  }

  const token = newToken();
  const tokenHash = hashToken(token);
  const expiresAt = new Date(Date.now() + SESSION_TTL_HOURS * 3600 * 1000);

  await pool.query(
    'INSERT INTO sessions (token_hash, user_id, expires_at, ip_address, user_agent) VALUES ($1, $2, $3, $4, $5)',
    [tokenHash, user.id, expiresAt, req.ip, req.headers['user-agent'] || null]
  );

  await logAttempt(true);
  setSessionCookie(res, token, expiresAt);
  res.json({ ok: true });
}));

// ---------- logout ----------

app.post('/logout', asyncHandler(async (req, res) => {
  const cookies = cookie.parse(req.headers.cookie || '');
  const token = cookies[COOKIE_NAME];
  if (token) {
    await pool.query('DELETE FROM sessions WHERE token_hash = $1', [hashToken(token)]);
  }
  clearSessionCookie(res);
  res.json({ ok: true });
}));

// ---------- verify ----------
// This is the endpoint nginx's auth_request calls before serving any protected page.
// Optional header X-Required-Service checks entitlement for a specific service,
// not just "is logged in".

// ---------- OAuth (Google, GitHub, Discord) ----------
// Deliberately limited to providers that are free and self-serve with no
// review/waiting period: Google and GitHub OAuth apps activate instantly,
// same for Discord. Facebook/LinkedIn require app review before going live,
// Apple Sign In requires a paid ($99/yr) developer account — excluded.
//
// A provider is "enabled" purely by having its CLIENT_ID/CLIENT_SECRET set in
// .env. Unset ones 404 on /auth/:provider/start rather than crashing, so you
// can add providers one at a time as you create each app.

const OAUTH_REDIRECT_BASE = process.env.OAUTH_REDIRECT_BASE || 'https://digi-line.eu';

const OAUTH_PROVIDERS = {
  google: {
    authUrl: 'https://accounts.google.com/o/oauth2/v2/auth',
    tokenUrl: 'https://oauth2.googleapis.com/token',
    userinfoUrl: 'https://openidconnect.googleapis.com/v1/userinfo',
    scope: 'openid email profile',
    clientId: process.env.GOOGLE_CLIENT_ID,
    clientSecret: process.env.GOOGLE_CLIENT_SECRET,
    extraAuthParams: { access_type: 'online', prompt: 'select_account' },
    mapProfile: async (p) => ({
      providerId: p.sub,
      email: p.email_verified ? p.email : null,
      name: p.name || null,
    }),
  },
  github: {
    authUrl: 'https://github.com/login/oauth/authorize',
    tokenUrl: 'https://github.com/login/oauth/access_token',
    userinfoUrl: 'https://api.github.com/user',
    scope: 'read:user user:email',
    clientId: process.env.GITHUB_CLIENT_ID,
    clientSecret: process.env.GITHUB_CLIENT_SECRET,
    // GitHub's /user omits email when the user has it set private, so we
    // fall back to the dedicated emails endpoint for the verified primary one.
    mapProfile: async (p, accessToken) => {
      let email = p.email;
      if (!email) {
        const emailsRes = await fetch('https://api.github.com/user/emails', {
          headers: { Authorization: `Bearer ${accessToken}`, 'User-Agent': 'digi-line-auth', Accept: 'application/vnd.github+json' },
        });
        const emails = await emailsRes.json().catch(() => []);
        const primary = Array.isArray(emails) ? emails.find((e) => e.primary && e.verified) : null;
        email = primary ? primary.email : null;
      }
      return { providerId: String(p.id), email, name: p.name || p.login || null };
    },
  },
  discord: {
    authUrl: 'https://discord.com/api/oauth2/authorize',
    tokenUrl: 'https://discord.com/api/oauth2/token',
    userinfoUrl: 'https://discord.com/api/users/@me',
    scope: 'identify email',
    clientId: process.env.DISCORD_CLIENT_ID,
    clientSecret: process.env.DISCORD_CLIENT_SECRET,
    mapProfile: async (p) => ({
      providerId: p.id,
      email: p.verified ? p.email : null,
      name: p.global_name || p.username || null,
    }),
  },
};

// Short-lived CSRF state for the OAuth redirect round trip. In-memory is fine
// here — these live minutes, not the session-length concern /verify handles —
// but this DOES mean state won't survive a restart mid-flow, or being spread
// across more than one auth-service replica. Fine at current scale; revisit
// (move to a shared store) if you ever run more than one instance of this.
const oauthStates = new Map();
function newOauthState(provider, redirectTo) {
  for (const [k, v] of oauthStates) if (v.expires < Date.now()) oauthStates.delete(k);
  const state = crypto.randomBytes(24).toString('hex');
  oauthStates.set(state, { provider, redirectTo, expires: Date.now() + 5 * 60 * 1000 });
  return state;
}

app.get('/auth/:provider/start', (req, res) => {
  const providerName = req.params.provider;
  const provider = OAUTH_PROVIDERS[providerName];
  if (!provider || !provider.clientId) return res.status(404).json({ error: 'provider_not_available' });

  const redirectTo = typeof req.query.redirect === 'string' && req.query.redirect.startsWith('/')
    ? req.query.redirect
    : '/dashboard.html';
  const state = newOauthState(providerName, redirectTo);

  const url = new URL(provider.authUrl);
  url.searchParams.set('client_id', provider.clientId);
  url.searchParams.set('redirect_uri', `${OAUTH_REDIRECT_BASE}/auth/${providerName}/callback`);
  url.searchParams.set('response_type', 'code');
  url.searchParams.set('scope', provider.scope);
  url.searchParams.set('state', state);
  for (const [k, v] of Object.entries(provider.extraAuthParams || {})) url.searchParams.set(k, v);

  res.redirect(url.toString());
});

app.get('/auth/:provider/callback', asyncHandler(async (req, res) => {
  const providerName = req.params.provider;
  const provider = OAUTH_PROVIDERS[providerName];
  if (!provider || !provider.clientId) return res.redirect('/login/?error=oauth_unavailable');

  const { code, state } = req.query;
  const saved = typeof state === 'string' && oauthStates.get(state);
  if (!saved || saved.provider !== providerName) {
    return res.redirect('/login/?error=oauth_state');
  }
  oauthStates.delete(state);

  if (typeof code !== 'string') return res.redirect('/login/?error=oauth_failed');

  const tokenRes = await fetch(provider.tokenUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Accept: 'application/json' },
    body: new URLSearchParams({
      client_id: provider.clientId,
      client_secret: provider.clientSecret,
      code,
      redirect_uri: `${OAUTH_REDIRECT_BASE}/auth/${providerName}/callback`,
      grant_type: 'authorization_code',
    }),
  });
  const tokenData = await tokenRes.json().catch(() => ({}));
  if (!tokenData.access_token) {
    console.error('oauth token exchange failed', providerName, tokenData);
    return res.redirect('/login/?error=oauth_failed');
  }

  const profileRes = await fetch(provider.userinfoUrl, {
    headers: { Authorization: `Bearer ${tokenData.access_token}`, 'User-Agent': 'digi-line-auth', Accept: 'application/json' },
  });
  const profileRaw = await profileRes.json().catch(() => ({}));
  const profile = await provider.mapProfile(profileRaw, tokenData.access_token);

  if (!profile.email) {
    // no verified email from the provider — nothing safe to key an account on
    return res.redirect('/login/?error=oauth_no_email');
  }
  const email = profile.email.toLowerCase().trim();

  const identityRes = await pool.query(
    'SELECT user_id FROM oauth_identities WHERE provider = $1 AND provider_user_id = $2',
    [providerName, profile.providerId]
  );

  let userId;
  if (identityRes.rows.length > 0) {
    userId = identityRes.rows[0].user_id;
  } else {
    // No existing link for this provider account. Match by email so someone
    // who already has a password account doesn't end up with a second,
    // duplicate account just because they used Google this time.
    const userRes = await pool.query('SELECT id FROM users WHERE email = $1', [email]);
    if (userRes.rows.length > 0) {
      userId = userRes.rows[0].id;
    } else {
      const newUser = await pool.query(
        'INSERT INTO users (email, password_hash, display_name) VALUES ($1, NULL, $2) RETURNING id',
        [email, profile.name]
      );
      userId = newUser.rows[0].id;
    }
    await pool.query(
      `INSERT INTO oauth_identities (user_id, provider, provider_user_id, email)
       VALUES ($1, $2, $3, $4)
       ON CONFLICT (provider, provider_user_id) DO NOTHING`,
      [userId, providerName, profile.providerId, email]
    );
  }

  const userCheck = await pool.query('SELECT is_active FROM users WHERE id = $1', [userId]);
  if (!userCheck.rows[0] || !userCheck.rows[0].is_active) {
    return res.redirect('/login/?error=account_disabled');
  }

  const token = newToken();
  const expiresAt = new Date(Date.now() + SESSION_TTL_HOURS * 3600 * 1000);
  await pool.query(
    'INSERT INTO sessions (token_hash, user_id, expires_at, ip_address, user_agent) VALUES ($1, $2, $3, $4, $5)',
    [hashToken(token), userId, expiresAt, req.ip, req.headers['user-agent'] || null]
  );
  setSessionCookie(res, token, expiresAt);

  // clean redirect — no code/state ever lingers in the address bar
  res.redirect(saved.redirectTo);
}));

// ---------- shared session lookup ----------
// Used by /verify and /me/preferences so the "is this cookie a valid, active
// session" query lives in exactly one place.

async function requireSession(req, res, next) {
  const cookies = cookie.parse(req.headers.cookie || '');
  const token = cookies[COOKIE_NAME];
  if (!token) return res.status(401).json({ error: 'no_session' });

  const tokenHash = hashToken(token);
  const result = await pool.query(
    `SELECT s.user_id, s.expires_at, u.email, u.is_active, u.display_name,
            u.preferred_language, u.preferred_theme
     FROM sessions s JOIN users u ON u.id = s.user_id
     WHERE s.token_hash = $1`,
    [tokenHash]
  );
  if (result.rows.length === 0) return res.status(401).json({ error: 'invalid_session' });

  const session = result.rows[0];
  if (new Date(session.expires_at) < new Date() || !session.is_active) {
    await pool.query('DELETE FROM sessions WHERE token_hash = $1', [tokenHash]);
    return res.status(401).json({ error: 'expired_or_disabled' });
  }

  req.session = session;
  req.sessionTokenHash = tokenHash;
  next();
}

app.get('/verify', asyncHandler(requireSession), asyncHandler(async (req, res) => {
  const session = req.session;

  const requiredService = req.headers['x-required-service'];
  if (requiredService) {
    const ent = await pool.query(
      `SELECT us.status, us.expires_at FROM user_services us
       JOIN services sv ON sv.id = us.service_id
       WHERE us.user_id = $1 AND sv.slug = $2`,
      [session.user_id, requiredService]
    );
    const row = ent.rows[0];
    const active = row && row.status === 'active' &&
      (!row.expires_at || new Date(row.expires_at) > new Date());
    if (!active) return res.status(403).json({ error: 'service_not_active' });
  }

  // nginx can pass these through to the upstream app if useful (e.g. dashboards
  // that want to greet the user by email without a second DB round trip)
  res.setHeader('X-User-Id', session.user_id);
  res.setHeader('X-User-Email', session.email);
  res.setHeader('X-User-Name', encodeURIComponent(session.display_name || ''));
  res.setHeader('X-User-Language', session.preferred_language);
  res.setHeader('X-User-Theme', session.preferred_theme);
  res.status(200).json({
    ok: true,
    user: {
      id: session.user_id,
      email: session.email,
      name: session.display_name,
      language: session.preferred_language,
      theme: session.preferred_theme,
    },
  });
}));

// ---------- preferences (language / theme) ----------
// Stored per-user in the DB (not just a cookie) so they follow the person
// across devices and browsers, not just this one session.

app.put('/me/preferences', asyncHandler(requireSession), asyncHandler(async (req, res) => {
  const { language, theme } = req.body || {};
  if (language !== undefined && !['en', 'de'].includes(language)) {
    return res.status(400).json({ error: 'invalid_input' });
  }
  if (theme !== undefined && !['light', 'dark'].includes(theme)) {
    return res.status(400).json({ error: 'invalid_input' });
  }
  await pool.query(
    `UPDATE users SET
       preferred_language = COALESCE($1, preferred_language),
       preferred_theme = COALESCE($2, preferred_theme)
     WHERE id = $3`,
    [language || null, theme || null, req.session.user_id]
  );
  res.json({ ok: true });
}));

// ---------- admin: manage the service catalog ----------
// Called manually (curl) or from an n8n workflow, e.g. triggered by a payment webhook.

app.post('/admin/services', requireAdmin, asyncHandler(async (req, res) => {
  const { slug, name } = req.body || {};
  if (!slug || !name) return res.status(400).json({ error: 'invalid_input' });
  const result = await pool.query(
    'INSERT INTO services (slug, name) VALUES ($1, $2) ON CONFLICT (slug) DO NOTHING RETURNING id',
    [slug, name]
  );
  res.json({ ok: true, created: result.rows.length > 0 });
}));

// ---------- admin: grant / revoke / suspend a service for a user ----------

app.post('/admin/grant', requireAdmin, asyncHandler(async (req, res) => {
  const { email, service_slug, status, expires_at } = req.body || {};
  if (!email || !service_slug) return res.status(400).json({ error: 'invalid_input' });

  const userRes = await pool.query('SELECT id FROM users WHERE email = $1', [email.toLowerCase().trim()]);
  if (userRes.rows.length === 0) return res.status(404).json({ error: 'user_not_found' });

  const svcRes = await pool.query('SELECT id FROM services WHERE slug = $1', [service_slug]);
  if (svcRes.rows.length === 0) return res.status(404).json({ error: 'service_not_found' });

  await pool.query(
    `INSERT INTO user_services (user_id, service_id, status, activated_at, expires_at)
     VALUES ($1, $2, $3, now(), $4)
     ON CONFLICT (user_id, service_id)
     DO UPDATE SET status = $3, activated_at = now(), expires_at = $4`,
    [userRes.rows[0].id, svcRes.rows[0].id, status || 'active', expires_at || null]
  );
  res.json({ ok: true });
}));

// ---------- admin: list a user's active services (handy for building a dashboard) ----------

app.get('/admin/user/:email/services', requireAdmin, asyncHandler(async (req, res) => {
  const result = await pool.query(
    `SELECT sv.slug, sv.name, us.status, us.activated_at, us.expires_at
     FROM user_services us
     JOIN services sv ON sv.id = us.service_id
     JOIN users u ON u.id = us.user_id
     WHERE u.email = $1`,
    [req.params.email.toLowerCase().trim()]
  );
  res.json({ ok: true, services: result.rows });
}));

// ---------- health check ----------
// For Docker HEALTHCHECK / uptime monitoring. Checks the DB round trip too,
// since a wedged pool is the most likely failure mode here, and this service
// gates every protected page across every property behind digi-line.eu.

app.get('/healthz', async (req, res) => {
  try {
    await pool.query('SELECT 1');
    res.status(200).json({ ok: true });
  } catch (err) {
    console.error('healthz db check failed', err);
    res.status(503).json({ ok: false });
  }
});

const server = app.listen(4000, () => console.log('auth-service listening on :4000'));

// Graceful shutdown so in-flight requests finish and the pool closes cleanly
// on redeploys, instead of dropping connections mid-request.
function shutdown(signal) {
  console.log(`${signal} received, shutting down`);
  server.close(() => {
    pool.end().then(() => process.exit(0)).catch(() => process.exit(1));
  });
  setTimeout(() => process.exit(1), 10_000).unref();
}
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
