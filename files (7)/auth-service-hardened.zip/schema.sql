-- Auth database schema
-- Design principle: adding a new service NEVER requires an ALTER TABLE.
-- You INSERT a row into `services`, then INSERT/UPDATE rows in `user_services`
-- to grant or revoke it per user. The users table itself never changes.

CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE users (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email         TEXT UNIQUE NOT NULL,
  password_hash TEXT,                   -- argon2id, never plain/reversible. NULL = OAuth-only account, no password login possible until they set one
  display_name  TEXT,                   -- optional, from signup form or OAuth provider profile
  preferred_language TEXT NOT NULL DEFAULT 'en',  -- 'en' | 'de' for now
  preferred_theme    TEXT NOT NULL DEFAULT 'light', -- 'light' | 'dark'
  mfa_secret    TEXT,                   -- null until user enables MFA
  is_active     BOOLEAN NOT NULL DEFAULT true,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Links a user to one or more third-party identity providers (Google, GitHub,
-- Discord, ...). Kept as its own table, separate from `users`, on purpose:
-- one person can sign in with password AND Google AND GitHub, and this way
-- adding a new provider is a new row type here, never a new users column.
-- provider_user_id is the STABLE id the provider gives us — never their email,
-- since a person can change their email at Google but their Google account id
-- never changes. Email is stored here too, but only for reference/debugging.
CREATE TABLE oauth_identities (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id           UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  provider          TEXT NOT NULL,      -- 'google' | 'github' | 'discord'
  provider_user_id  TEXT NOT NULL,
  email             TEXT,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (provider, provider_user_id)
);
CREATE INDEX idx_oauth_identities_user ON oauth_identities(user_id);

CREATE TABLE sessions (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  token_hash  TEXT UNIQUE NOT NULL,     -- SHA-256 of the session token, never the raw token
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at  TIMESTAMPTZ NOT NULL,
  ip_address  TEXT,
  user_agent  TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_sessions_user_id    ON sessions(user_id);
CREATE INDEX idx_sessions_expires_at ON sessions(expires_at);

-- The catalog of everything you sell/offer. Add a row here whenever you launch
-- a new service — no code deploy or migration needed for the DB side.
CREATE TABLE services (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug       TEXT UNIQUE NOT NULL,      -- e.g. 'wa-automation', 'qr-branding', 'newsletter-pro'
  name       TEXT NOT NULL,             -- display name
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Who has access to what. This is the entitlements table nginx/the app checks
-- on every request. One row per (user, service) pair.
CREATE TABLE user_services (
  user_id      UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  service_id   UUID NOT NULL REFERENCES services(id) ON DELETE CASCADE,
  status       TEXT NOT NULL DEFAULT 'active',  -- 'active' | 'suspended' | 'cancelled'
  activated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at   TIMESTAMPTZ,             -- optional: for time-limited/subscription access
  PRIMARY KEY (user_id, service_id)
);
CREATE INDEX idx_user_services_user_id ON user_services(user_id);

-- Login attempt log, used for rate limiting / brute-force detection at the DB level
-- (in addition to the in-process rate limiter in server.js).
-- RETENTION: this grows forever with no cleanup unless you add one. It holds IP
-- addresses (personal data), so it needs the same cron treatment as `sessions` —
-- e.g. `DELETE FROM login_attempts WHERE created_at < now() - interval '90 days';`
-- on the same daily job. Pick a retention window that matches what you actually
-- need for abuse investigation, not "forever by default."
CREATE TABLE login_attempts (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email      TEXT NOT NULL,
  ip_address TEXT NOT NULL,
  success    BOOLEAN NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_login_attempts_lookup ON login_attempts(email, ip_address, created_at);
